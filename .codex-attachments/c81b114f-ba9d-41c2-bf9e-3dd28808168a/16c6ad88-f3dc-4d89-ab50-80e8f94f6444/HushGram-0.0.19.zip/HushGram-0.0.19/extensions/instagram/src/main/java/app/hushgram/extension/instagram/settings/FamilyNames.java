/*
 * Copyright 2026 Hushfacebook contributors
 * https://github.com/SysAdminDoc/Hushfacebook
 *
 * Modified for HushGram (Instagram), 2026.
 */
package app.hushgram.extension.instagram.settings;

/**
 * The name each patch goes by in Morphe Manager, which is also the family its hooks report
 * under in Hook status.
 *
 * <p>Compile-time constants, so a hook that names its family inlines the text and loads no
 * class. That matters for the hooks that can run before HushGram has a context, such as the
 * signature read Instagram makes while its content providers start: touching {@link PatchFamily}
 * there would load the settings with no context to read them from.
 */
public final class FamilyNames {
    public static final String HIDE_ADS = "Hide ads";
    public static final String SANITIZE_SHARING_LINKS = "Sanitize sharing links";
    public static final String EXTERNAL_BROWSER = "Open links in external browser";
    public static final String BUILD_EXPIRED_POPUP = "Remove build expired popup";
    public static final String RESTORE_TRUST = "Restore trust on re-signed builds";
    public static final String REMOVE_AD_ID = "Remove the advertising ID";
    public static final String REEL_WATCH_HISTORY = "Don't send reel watch history";
    public static final String STORY_AUTO_ADVANCE = "Stop Story auto-advance";
    public static final String STORY_TIME = "Show a story's exact time";
    public static final String STORY_MENTIONS = "See who a story mentions";
    public static final String STORY_FOLLOW = "Hide Follow on stories";
    public static final String POST_TIME = "Show a post's exact time";
    public static final String HIDDEN_LIKE_COUNTS = "Show hidden like counts";
    public static final String BACK_LEAVES_HOME = "Back leaves Home";
    public static final String HOME_PLACE = "Keep your place in Home";
    public static final String STORY_LOOP = "Loop a story";
    public static final String SMOOTH_STORY_OPEN = "Smooth story opening";
    public static final String STORY_ZOOM_PLAY = "Keep stories playing while zooming";
    public static final String STORY_PRIORITY = "Stories priority";
    public static final String STORY_SOUND = "Start stories with sound";
    public static final String STORY_SWIPE_REPLY = "Stop swipe up to reply";
    public static final String STORY_REPLY_BOX = "Hide the reply box on stories";
    public static final String STORY_FONTS = "Story text fonts";
    public static final String STORY_UPLOAD_QUALITY = "Upload stories at full quality";
    public static final String FEED_SOUND = "Start feed videos with sound";
    public static final String FEED_TAP_PAUSE = "Tap a feed video to pause it";
    public static final String FEED_SEEK_BAR = "Seek bar on feed videos";
    public static final String LONG_PRESS_ZOOM = "Long press to zoom";
    public static final String ROUNDED_POST_CORNERS = "Rounded post corners";
    public static final String CAROUSEL_ARROWS = "Carousel arrows";
    public static final String AMBIENT_LIGHT = "Ambient light";
    public static final String STORY_SEEN = "View stories anonymously";
    public static final String DM_MEDIA_SEEN = "View DM photos and videos anonymously";
    public static final String SPOOF_LOCATION = "Spoof location";
    public static final String APP_PROXY = "App-only proxy";
    public static final String SETUP_POPUPS = "Skip the contacts and location popups";
    public static final String AD_DATA_REMINDER = "Skip the ad data reminder";
    public static final String THREAD_SEEN = "Read messages without the seen receipt";
    public static final String TYPING = "Hide that you're typing";
    public static final String ACTIVE_STATUS = "Hide your active status";
    public static final String LAST_ACTIVE = "Show when someone was last active";
    public static final String MESSAGES_LOCK = "Lock your messages";
    public static final String STORIES_TRAY = "Hide suggested stories";
    public static final String STORY_RING = "Story ring size";
    public static final String STORY_PROGRESS_BAR = "Thicker story progress bar";
    public static final String STORY_SEEK_BAR = "Seek bar on stories";
    public static final String STORY_SPEED = "Speed button on stories";
    public static final String FEED_REELS = "Hide Reels in the feed";
    public static final String FEED_SUGGESTIONS = "Hide suggested posts";
    public static final String HOME_FEED = "Hide the home feed";
    public static final String FOLLOWING_FEED = "Start Home on Following";
    public static final String SWIPE_TO_CREATE = "Stop swipe to create";
    public static final String TAB_SWIPE = "Stop swiping between tabs";
    public static final String TAB_BAR_LAYOUT = "Tab bar layout";
    public static final String FULL_RESOLUTION = "Full resolution photos";
    public static final String META_AI = "Hide Meta AI";
    public static final String EXPLORE_GRID = "Hide the Explore grid";
    public static final String RECENT_SEARCHES = "Don't save recent searches";
    public static final String ALL_RECENT_SEARCHES = "Show all recent searches";
    public static final String EXPLORE_MENU = "Explore without personalization";
    public static final String NOTES_ROW = "Hide the notes row";
    public static final String INBOX_SEARCH = "Hide the search bar in Messages";
    public static final String INBOX_SUGGESTIONS = "Hide suggested accounts in DMs";
    public static final String INSTANTS = "Hide Instants";
    public static final String SHARE_SHEET = "Hide group buttons on the share sheet";
    public static final String REPOST_BUTTON = "Hide the Repost button";
    public static final String HIDE_SHARE_BUTTON = "Hide the Share button";
    public static final String BOTTOM_SPACE = "Remove the empty space at the bottom";
    public static final String PHONE_LAYOUT = "Phone layout on big screens";
    public static final String GLASS_TAB_BAR = "Glass tab bar";
    public static final String FULL_SCREEN_BARS = "Full screen Reels and Home";
    public static final String SAVED_ON_PROFILE = "Saved on your profile";
    public static final String STOP_HEARTBEAT = "Stop background wake-ups";
    public static final String REFRESH_RATE = "Use the highest refresh rate";
    public static final String EMOJI_STYLE = "Emoji style";
    public static final String ACCENT_COLOR = "Accent color";
    public static final String LAUNCH_SCREEN = "HushGram launch screen";
    public static final String HEADER_TEXT = "Home header text";
    public static final String APP_ICON = "Pick the app icon";
    public static final String SETTINGS_ROWS = "Hide rows in Instagram's settings";
    public static final String FONT = "Font";
    public static final String NOTIFICATION_GROUPS = "Group Instagram's notifications";
    public static final String HDR_BOOST = "Turn off HDR brightness boosts";
    public static final String STOP_LOOPING = "Stop videos looping";
    public static final String BACKGROUND_PLAY = "Keep playing in the background";
    public static final String MEDIA_CACHE = "Clear the media cache";
    public static final String FRIENDSHIP_STATUS = "Show if a profile follows you";
    public static final String PROFILE_SUGGESTIONS = "Hide suggested people on profiles";
    public static final String PROFILE_HIGHLIGHTS = "Hide highlights";
    public static final String PROFILE_TABS = "Hide profile tabs";
    public static final String THREADS_BUTTON = "Hide the Threads button";
    public static final String PROFILE_NOTES = "Hide Notes on profile pictures";
    public static final String PROFILE_POSTS_LIST = "Profile posts as a list";
    public static final String PROFILE_GRID_JUMP = "Jump a profile's posts to a date";
    public static final String COMMENT_COPY = "Copy comment";
    public static final String COMMENT_PHOTO = "Save comment photo";
    public static final String PROFILE_PICTURE = "Save profile picture";
    public static final String VOICE_MESSAGE = "Download voice messages";
    public static final String HIDE_COMMENTS = "Hide comments";
    public static final String COMMENT_EMOJI_ROW = "Hide the comment emoji row";
    public static final String COMMENT_KEYBOARD = "Open comments without the keyboard";
    public static final String FEED_FOLLOW = "Hide Follow on feed posts";
    public static final String ACTIVITY_BUBBLES = "Hide activity bubbles";
    public static final String HIDE_CAPTIONS = "Hide captions";
    public static final String FEED_AUDIO_ICON = "Hide the audio icon on posts";
    public static final String HOME_TOP_BAR = "Keep Home's top bar";
    public static final String REEL_DECLUTTER = "Clean up Reels";
    public static final String KEEP_REELS_TOP_BAR = "Keep the Reels top bar";
    public static final String REEL_DOWNLOAD = "Download any reel";
    public static final String DOUBLE_TAP_LIKE = "Turn off double tap to like";
    public static final String LIKE_ANIMATION = "Change the like animation";
    public static final String REELS_TAB = "Hide the Reels tab";
    public static final String REELS_SUGGESTIONS = "Hide suggested accounts in Reels";
    public static final String PAID_PARTNERSHIP_REELS = "Hide paid partnership Reels";
    public static final String AI_LABELED_REELS = "Hide AI-labeled reels";
    public static final String CAPTION_WORD_REELS = "Hide reels by caption words";
    public static final String LOW_VIEW_REELS = "Hide reels with few views";
    public static final String KEEP_REEL_SPEED = "Keep the reel speed";
    public static final String REEL_POST_TIME = "Show a reel's exact time";
    public static final String REEL_SEEK_BAR = "Keep a seek bar on Reels";
    public static final String REEL_BLUR_BARS = "Blur the bars around Reels";
    public static final String REEL_TAP_AND_VOLUME = "Control taps and volume on Reels";
    public static final String REEL_SOUND = "Start reels with sound";
    public static final String REEL_ZOOM = "Pinch to zoom on Reels";
    public static final String REEL_AUTO_SCROLL = "Keep Reels auto scroll on";
    public static final String REEL_SCROLLING = "Stop Reels scrolling";
    public static final String SWIPE_TO_PROFILE = "Swipe left to open the profile";
    public static final String REEL_ORIGIN = "Find the reel you came from";
    public static final String STORY_DOWNLOAD = "Download any story";
    public static final String VIDEO_DOWNLOAD = "Download any video";
    public static final String TAP_TO_PLAY = "Tap to play";
    public static final String RESUME_LONG_VIDEOS = "Resume long videos";
    public static final String PLAYBACK_QUALITY = "Default playback quality";
    public static final String DATA_SAVER = "Data saver";
    public static final String TRANSLATED_START = "Start on x86 devices";
    public static final String PURE_BLACK = "Pure black dark mode";
    public static final String VERSION_CODE = "Change version code";

    private FamilyNames() {
    }
    public static final String SCREENSHOT_REPORTS = "Don't report screenshots";
    public static final String BLEND_VISITS = "Don't report Blend visits";
    public static final String SCREENSHOT_BLOCK = "Allow screenshots";
    public static final String KEEP_IN_CHAT = "Keep in chat";
    public static final String VIEW_ONCE_MARK = "Mark one-time photos and videos";
    public static final String CHAT_REELS = "Swipe through a chat's reels";
    public static final String CHAT_HISTORY = "Chat history tools";
    public static final String PREVIEW_CHATS = "Preview chats";
    public static final String ASK_BEFORE_CALL = "Ask before a call";
    public static final String MESSAGE_BOX = "Message box buttons";
    public static final String PLUS_MENU = "Chat plus menu";
    public static final String GLASS_CHAT = "Glass in chats";
    public static final String ASK_BEFORE_LIKE = "Ask before a like";
    public static final String ASK_BEFORE_REFRESH = "Ask before a refresh";
    public static final String SAVE_TRAY = "Skip the collections tray";
    public static final String LIVE_SEEN = "View live anonymously";
}
